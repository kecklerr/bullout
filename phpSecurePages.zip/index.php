<HTML><HEAD>
<TITLE>Index</TITLE>
</HEAD>

<BODY style="font-family:arial;font-size:16px;">
<P>This is a <b>non-secure</b> test page.</P>



<P><A HREF="test.php">LogIn to test page 1</A><BR>
<A HREF="test2.php">LogIn to test page 2</A><BR>
<A HREF="test3.php">LogIn to test page 3</A></P>





</BODY></HTML>
